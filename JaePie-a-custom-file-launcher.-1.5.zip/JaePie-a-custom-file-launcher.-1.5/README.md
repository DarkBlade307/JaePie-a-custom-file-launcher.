# JaePie-a-custom-file-launcher.
This is JaePie, the first of my projects
# Installation
Open the installer file, click INSTALL NOW and the program will install. It will create an application and two folders. A programs folder and an importantfiles folder. If I say programs folder, i mean the one made by the program and not the windows one.
# Registering Programs
First you need to copy/move the program file into the programs folder. Then you need to do one of the two:
# 1)
Navigate to the importantfiles folder and open one of the three .txt files. You then need to erase everything on the file and replace it with the name of the file you want to assign the button to (the button number is on the name of the .txt file.). Save the file and open JaePie.
# 2)
Open JaePie and navigate to the Assign Buttons tab, type the name of the file in the text feild and click on one of the buttons beside it to assign the file.
